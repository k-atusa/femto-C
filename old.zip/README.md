# TSLL
Test Script Low Level

defines minimal C front-end, LLVM IR middle-end, x86/64/arm back-end for test and practice
